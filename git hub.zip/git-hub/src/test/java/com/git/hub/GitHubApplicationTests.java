package com.git.hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
